$('noscript').remove();
$('canvas').remove();